package org.example;

import java.util.InputMismatchException;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        int opcion = 99999;

        Scanner input = new Scanner(System.in);

        while (opcion != 0){
            System.out.print("""
                    ========================================
                     SISTEMA DE GESTIÓN DE ASIGNATURA
                    ========================================
                    1. Crear Alumno
                    2. Crear Profesor
                    3. Mostrar Alumno
                    4. Mostrar Profesor
                    5. Mostrar Asignatura
                    6. Realizar actividad del Alumno
                    7. Realizar actividad del Profesor
                    8. Demostrar polimorfismo con Alumno
                    9. Demostrar polimorfismo con Profesor
                    0. Salir
                    ========================================
                    Seleccione una opción:
                    
                    """);
            try{
            System.out.print("Ingrese una opcion: ");
            opcion = input.nextInt();
            }   catch(Exception e){
                System.out.println("Error: debe ingresar un número entero.");

            }
            if (opcion >= 0 && opcion <= 9){
                switch (opcion){
                    case 1:
                        System.out.println();
                        break;
                    case 2:
                        System.out.println();
                        break;
                    case 3:
                        System.out.println();
                        break;
                    case 4:
                        System.out.println();
                        break;
                    case 5:
                        System.out.println();
                        break;
                    case 6:
                        System.out.println();
                        break;
                    case 7:
                        System.out.println();
                        break;
                    case 8:
                        System.out.println();
                        break;
                    case 9:
                        System.out.println();
                        break;
                    case 0:
                        System.out.println();
                        System.out.println("Gracias por utilizar nuestra APP");
                        break;
                    default:
                        System.out.println("Opción fuera de rango");
                        break;
                }
            }




            }

        }

    }
}